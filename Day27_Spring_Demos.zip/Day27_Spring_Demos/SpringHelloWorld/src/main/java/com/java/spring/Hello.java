package com.java.spring;

public interface Hello {
	String sayHello(String name);
}
