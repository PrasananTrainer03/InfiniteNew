public class P20 {
    public static void main(String[] args) {
        // byte b1;  
        // b1 = 25 + 110; 
    
        // System.out.println(b1);
        
        byte b1=120;
        b1+=3;
        System.out.println(b1);
        b1 = b1 + 12; 
         System.out.println(b1);
    }
}