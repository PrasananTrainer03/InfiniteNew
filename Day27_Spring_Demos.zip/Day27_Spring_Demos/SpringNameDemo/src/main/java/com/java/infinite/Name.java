package com.java.infinite;

public interface Name {
	String fullName();
}
