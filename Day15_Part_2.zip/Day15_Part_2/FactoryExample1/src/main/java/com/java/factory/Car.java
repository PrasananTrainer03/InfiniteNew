package com.java.factory;

public class Car extends Vehicle {

	@Override
	public void name() {
		System.out.println("Its Maruthi ZXI car...");
	}

	@Override
	public void price() {
		System.out.println("Its 8Lacks...");
	}

}
