package com.java.day3;

public enum DbOperations {
   CREATE, READ, UPDATE, DELETE
}