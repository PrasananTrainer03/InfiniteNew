package com.java.jsp;

public class Greeting {

	private String greet="Good Morning...";

	public String getGreet() {
		return greet;
	}

	public void setGreet(String greet) {
		this.greet = greet;
	}
	
	
}
