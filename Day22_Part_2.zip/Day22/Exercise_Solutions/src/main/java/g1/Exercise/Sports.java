package g1.Exercise;

public class Sports extends Books {

	@Override
	public void bookName() {
		System.out.println("Book Name is Cricket about Worldcup ");
	}

	@Override
	public void author() {
		System.out.println("Charu Sharma...");
	}

}
