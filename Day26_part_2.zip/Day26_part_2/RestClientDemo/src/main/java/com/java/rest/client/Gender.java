package com.java.rest.client;

public enum Gender {
	MALE, FEMALE
}
