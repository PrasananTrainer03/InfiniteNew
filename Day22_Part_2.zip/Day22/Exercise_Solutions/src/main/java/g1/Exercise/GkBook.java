package g1.Exercise;

public interface GkBook {

	void bookName();
	void author();
}
