package infinite.FactoryDemo2;

public class Tenth extends Student {

	@Override
	public void name() {
		System.out.println("Name is Kasyap...");
	}

	@Override
	public void age() {
		System.out.println("Age is 15 years...");
	}

	@Override
	public void course() {
		System.out.println("Doing SSC from Central Board...");
	}

}
