package com.java.lms;

public enum LeaveStatus {

	PENDING, APPROVED, DENIED
}
