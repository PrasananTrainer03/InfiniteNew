public class ArgsDemo {
    String company = "Hexaware";
    public static void main(String[] args) {
        System.out.println(args[0] + " " +args[2]);
    }
}
