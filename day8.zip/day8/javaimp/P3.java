public class P3 {
    public static void main(String[] args) {
        byte b=4;
        int x=(Integer)b;
          System.out.println(x);
        int y =12;
        byte p = (Byte)y;
        System.out.println(p);
    }
}