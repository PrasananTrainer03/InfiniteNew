package g1.Exercise;

public class Novels extends Books {

	@Override
	public void bookName() {
		System.out.println("The Sky is Falling...");
	}

	@Override
	public void author() {
		System.out.println("Author Sidney Sheldon...");
	}

}
