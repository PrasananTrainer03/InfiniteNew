package com.java.day3;

public class FinalEx {
    public static void main(String[] args) {
        final String name="Hexaware";
        System.out.println("Name is  " +name);
        name = "Raj";
    }
}