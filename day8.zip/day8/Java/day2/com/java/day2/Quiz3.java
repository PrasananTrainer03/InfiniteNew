package com.java.day2;

public class Quiz3 {
    public static void main(String[] args) {
        int[] a = new int[]{12,5,6,33};
        for(int i : a) {
            System.out.println(a);
        }
    }
}