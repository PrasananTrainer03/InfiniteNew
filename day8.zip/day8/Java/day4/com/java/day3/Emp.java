package com.java.day3;

public class Emp {
    private int empno;
    private String name;
    private double basic;

    /* writing getter for empno */ 
    public int getEmpno() {
        return empno;
    }
    /* writing setter for empno */ 
    public void setEmpno(int argEmpno) {
        empno = argEmpno;
    }
    /* Writing getter for name */
    public String getName() {
        return name;
    }
    /* writing setter for name */ 
    public void setName(String argName) {
        name = argName;
    }
    /* Writing getter for basic */ 
    public double getBasic() {
        return basic;
    }
    /* Writing setter for basic */
    public void setBasic(double argBasic) {
        basic = argBasic;
    }
}