package infinite.FactoryDemo2;

public class Inter extends Student {

	@Override
	public void name() {
		System.out.println("Name is Pragya...");
	}

	@Override
	public void age() {
		System.out.println("Age is 18 Years...");
	}

	@Override
	public void course() {
		System.out.println("Plus 2 from IPE Board...");
	}

}
