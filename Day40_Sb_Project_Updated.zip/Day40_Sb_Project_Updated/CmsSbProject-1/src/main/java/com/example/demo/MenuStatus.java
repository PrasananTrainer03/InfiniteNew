package com.example.demo;

public enum MenuStatus {
	AVAILABLE,NOTAVAILABLE
}
