package g1.Exercise;

public abstract class Books {

	public abstract void bookName();
	public abstract void author();
}
