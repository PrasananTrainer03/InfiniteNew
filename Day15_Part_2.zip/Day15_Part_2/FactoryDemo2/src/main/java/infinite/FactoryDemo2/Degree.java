package infinite.FactoryDemo2;

public class Degree extends Student {

	@Override
	public void name() {
		System.out.println("Student is Krishna Shashank...");
	}

	@Override
	public void age() {
		System.out.println("Age is 22 Years...");
	}

	@Override
	public void course() {
		System.out.println("B.tech from CS");
	}

	
}
