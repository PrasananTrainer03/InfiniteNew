package com.java.infinite;

import java.sql.Connection;

public abstract class ConnectionHelper {

	public abstract Connection getConnection();
}
