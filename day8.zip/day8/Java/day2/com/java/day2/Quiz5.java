package com.java.day2;

public class Quiz5 {
    public static void main(String[] args) {
        boolean flag=true;
        System.out.println("Boolean Value  " +flag);
    }
}