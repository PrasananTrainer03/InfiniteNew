package com.java.day1;

public class ArgsDemo {
    public static void main(String[] args) {
        System.out.println(args[1]);
    }
}