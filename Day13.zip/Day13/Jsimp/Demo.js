function sayHello() {
    alert("Welcome to Javascript...");
}