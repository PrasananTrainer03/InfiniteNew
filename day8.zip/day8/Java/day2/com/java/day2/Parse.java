package com.java.day2;

public class Parse {
    public static void main(String[] args) {
        String no = "12";
        int n = Integer.parseInt(no);
        System.out.println(++n);
    }
}