package com.example.demo.controller;

public enum Gender {
	MALE, FEMALE
}
