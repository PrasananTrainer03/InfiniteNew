package g1.Exercise;

public class Academic extends Books {

	@Override
	public void bookName() {
		System.out.println("Electronics reference");
	}

	@Override
	public void author() {
		System.out.println("BPB Publication");
	}
	
	

}
