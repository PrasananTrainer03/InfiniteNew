package com.java.infinite.model;

public enum Gender {
	MALE,FEMALE
}
