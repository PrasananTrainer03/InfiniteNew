package com.java.factory;

public  abstract class Vehicle {

	public abstract void name();
	public abstract void price();
}
