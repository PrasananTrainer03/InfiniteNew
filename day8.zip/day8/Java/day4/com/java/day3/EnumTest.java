package com.java.day3;

public class EnumTest {
    public static void main(String[] args) {
        // Flag op = Flag.INSERT;
        // System.out.println(op);
        //String s = Status.JOURNEY;
        Status s = Status.BOOKED;
        System.out.println(s);
    }
}