package infinite.FactoryDemo2;

public abstract class Student {

	public abstract void name();
	public abstract void age();
	public abstract void course();
}
