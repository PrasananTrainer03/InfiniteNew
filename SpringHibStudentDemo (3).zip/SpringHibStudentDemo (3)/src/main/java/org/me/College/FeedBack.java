package org.me.College;

public class FeedBack {
	private String fid;
	private String studentName;
	private String instructor;
	private String subject;
	private String fbvalue;
	public String getFid() {
		return fid;
	}
	public void setFid(String fid) {
		this.fid = fid;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getInstructor() {
		return instructor;
	}
	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getFbvalue() {
		return fbvalue;
	}
	public void setFbvalue(String fbvalue) {
		this.fbvalue = fbvalue;
	}
	
	
	

}
