package com.java.infinite.beans;

public enum Gender {

	MALE, FEMALE
}
