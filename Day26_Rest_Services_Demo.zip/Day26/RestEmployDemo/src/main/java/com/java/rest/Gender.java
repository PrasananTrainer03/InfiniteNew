package com.java.rest;

public enum Gender {
	MALE, FEMALE
}
