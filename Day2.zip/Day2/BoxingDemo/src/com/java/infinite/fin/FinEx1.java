package com.java.infinite.fin;

public class FinEx1 {

	public static void main(String[] args) {
		final String company="Infinite";
		System.out.println(company);
		//company="Infinite limited";
	}
}
