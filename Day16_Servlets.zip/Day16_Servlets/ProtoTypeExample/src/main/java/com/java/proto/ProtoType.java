package com.java.proto;

public interface ProtoType {

	public ProtoType getPrototype();
}
