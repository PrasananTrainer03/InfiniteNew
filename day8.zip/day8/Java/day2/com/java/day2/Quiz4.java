package com.java.day2;

public class Quiz4 {
    public static void main(String[] args) {
        int x=0;
        System.out.println("X value is  " +x);
    }
}