package com.java.infinite.fin;

final class Admin {
	void showInfo() {
		System.out.println("Admin at Chennai");
	}
	void training() {
		System.out.println("Training on Online Mode...");
	}
}

//class Prachi extends Admin {
//	
//}
public class FinalEx2 {

}
