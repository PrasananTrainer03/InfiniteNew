package com.java.infinite.good;

import org.junit.Test;

public class AppTest {

  @Test
  public void testMain() {
    App.main(null);
  }

}
