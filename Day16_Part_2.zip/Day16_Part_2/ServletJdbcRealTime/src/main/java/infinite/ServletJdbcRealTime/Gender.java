package infinite.ServletJdbcRealTime;

public enum Gender {
	MALE, FEMALE
}
