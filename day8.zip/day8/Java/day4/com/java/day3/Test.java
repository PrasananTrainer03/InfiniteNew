package com.java.day3;

public class Test {
    int a,b;
    Test(int a, int b) {
        this.a=a;
    }
}