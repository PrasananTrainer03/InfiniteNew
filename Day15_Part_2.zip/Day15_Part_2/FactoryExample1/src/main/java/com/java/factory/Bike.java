package com.java.factory;

public class Bike extends Vehicle {

	@Override
	public void name() {
		System.out.println("Its Passion Pro Bike...");
	}

	@Override
	public void price() {
		System.out.println("Its 90k...Price");
	}

	
}
